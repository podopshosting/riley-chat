exports.handler = async (event) => {
  return {
    statusCode: 200,
    headers: {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': '*',
      'Access-Control-Allow-Headers': '*'
    },
    body: JSON.stringify({
      success: true,
      data: {
        rollup: { totalLeads: 184, rileyConversations: 111, appointments: 102, costPerLead: "47.97" },
        locations: {
          reston: { name: 'Reston', phone: '200-402-3319', totalLeads: 23, appointments: 10, costPerLead: "36.42" },
          tampa: { name: 'Tampa', phone: '518-756-3309', totalLeads: 32, appointments: 16, costPerLead: "28.10" },
          dover: { name: 'Dover', phone: '248-866-5511', totalLeads: 26, appointments: 12, costPerLead: "43.14" },
          charlotte: { name: 'Charlotte', phone: '186-418-5423', totalLeads: 17, appointments: 19, costPerLead: "51.06" },
          marlton: { name: 'Marlton', phone: '494-724-8505', totalLeads: 28, appointments: 17, costPerLead: "52.51" },
          kingofprussia: { name: 'King of Prussia', phone: '130-897-0331', totalLeads: 26, appointments: 11, costPerLead: "43.50" },
          laurel: { name: 'Laurel', phone: '845-196-2272', totalLeads: 32, appointments: 10, costPerLead: "44.41" }
        }
      }
    })
  };
};