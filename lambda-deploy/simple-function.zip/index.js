const mysql = require('mysql2/promise');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const AWS = require('aws-sdk');
const bcrypt = require('bcryptjs');

const secretsManager = new AWS.SecretsManager({ region: 'us-east-2' });
let dbCredentials = null;
let dbPool = null;

// Cache credentials in Lambda memory to avoid repeated Secrets Manager calls
let cachedCredentials = null;

async function getDbPool() {
    if (dbPool) return dbPool;

    // Use environment variables (faster and more reliable)
    if (!cachedCredentials) {
        console.log('🔧 Loading database credentials...');
        console.log('DB_HOST:', process.env.DB_HOST ? 'SET' : 'NOT SET');
        console.log('DB_USER:', process.env.DB_USER ? 'SET' : 'NOT SET');
        console.log('DB_PASSWORD:', process.env.DB_PASSWORD ? 'SET' : 'NOT SET');
        console.log('DB_NAME:', process.env.DB_NAME ? 'SET' : 'NOT SET');

        if (process.env.DB_HOST && process.env.DB_USER && process.env.DB_PASSWORD) {
            cachedCredentials = {
                host: process.env.DB_HOST,
                username: process.env.DB_USER,
                password: process.env.DB_PASSWORD,
                database: process.env.DB_NAME || 'digitiv_staging'
            };
            console.log('✅ Using environment variables for database credentials');
            console.log('Host:', cachedCredentials.host);
            console.log('Database:', cachedCredentials.database);
        } else {
            console.log('❌ Environment variables not found, using fallback');
            throw new Error('Database environment variables not configured');
        }
    }

    // Optimized connection pool for high performance (no VPC)
    dbPool = mysql.createPool({
        host: cachedCredentials.host,
        user: cachedCredentials.username,
        password: cachedCredentials.password,
        database: cachedCredentials.database || cachedCredentials.dbname,
        port: 3306,
        connectionLimit: 25,           // Increased from 3 to 25 for better concurrency
        acquireTimeout: 15000,         // Increased from 3s to 15s
        // timeout: 45000,             // Removed - invalid option
        idleTimeout: 300000,           // 5 minutes idle timeout
        queueLimit: 50,                // Queue up to 50 requests
        reconnect: true,               // Auto-reconnect on connection loss
        ssl: { rejectUnauthorized: false },
        // Performance optimizations
        dateStrings: false,
        supportBigNumbers: true,
        bigNumberStrings: false,
        charset: 'utf8mb4'
    });

    console.log('🔧 Connection pool created with host:', cachedCredentials.host);

    // Warm up the connection pool
    try {
        const connection = await dbPool.getConnection();
        await connection.ping();
        connection.release();
        console.log('✅ Database connection pool warmed up successfully');
    } catch (error) {
        console.error('⚠️ Connection pool warmup failed:', error.message);
    }

    return dbPool;
}

// Retry function with exponential backoff
async function executeWithRetry(pool, query, params, maxRetries = 3) {
    let lastError;

    for (let attempt = 1; attempt <= maxRetries; attempt++) {
        try {
            console.log(`🔍 Database query attempt ${attempt}/${maxRetries}`);
            const result = await pool.execute(query, params);
            console.log(`✅ Database query successful on attempt ${attempt}`);
            return result;
        } catch (error) {
            lastError = error;
            console.error(`❌ Database query failed (attempt ${attempt}/${maxRetries}):`, error.message);

            // Don't retry on authentication errors or syntax errors
            if (error.code === 'ER_ACCESS_DENIED_ERROR' ||
                error.code === 'ER_PARSE_ERROR' ||
                error.code === 'ER_NO_SUCH_TABLE') {
                break;
            }

            // Wait before retry (exponential backoff: 100ms, 200ms, 400ms)
            if (attempt < maxRetries) {
                const delay = 100 * Math.pow(2, attempt - 1);
                console.log(`⏳ Retrying in ${delay}ms...`);
                await new Promise(resolve => setTimeout(resolve, delay));
            }
        }
    }

    throw lastError;
}

exports.handler = async (event) => {
    // Get origin from event headers for CORS
    const origin = event.headers?.origin || event.headers?.Origin;
    const allowedOrigins = ['https://www.mypodops.com', 'https://mypodops.com'];
    const isAllowedOrigin = allowedOrigins.includes(origin);

    const corsHeaders = {
        'Access-Control-Allow-Origin': isAllowedOrigin ? origin : 'https://www.mypodops.com',
        'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS, PATCH',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Requested-With, Accept, Origin',
        'Access-Control-Allow-Credentials': 'true',
        'Content-Type': 'application/json'
    };

    if (event.httpMethod === 'OPTIONS') {
        console.log('OPTIONS request received:', JSON.stringify(event, null, 2));
        console.log('Origin:', origin, 'Allowed:', isAllowedOrigin);
        return {
            statusCode: 200,
            headers: corsHeaders,
            body: JSON.stringify({ message: 'CORS preflight successful' })
        };
    }

    try {
        let path = event.path || '/';
        const method = event.httpMethod || 'GET';

        if (event.pathParameters && event.pathParameters.proxy) {
            path = '/' + event.pathParameters.proxy;
        }

        console.log(`Processing ${method} ${path}`);

        // Health check
        if (path === '/health' || path === '/' || path === '') {
            return {
                statusCode: 200,
                headers: corsHeaders,
                body: JSON.stringify({
                    success: true,
                    message: 'Lambda is healthy',
                    timestamp: new Date().toISOString()
                })
            };
        }

        // Secure database login for all users
        if (path === '/auth/login' && method === 'POST') {
            const totalStartTime = Date.now();
            console.log(`🚀 Login request started at ${new Date().toISOString()}`);

            try {
                const body = JSON.parse(event.body || '{}');
                const { email, password } = body;

                if (!email || !password) {
                    return {
                        statusCode: 400,
                        headers: corsHeaders,
                        body: JSON.stringify({ success: false, error: 'Email and password required' })
                    };
                }

                const pool = await getDbPool();

                // Optimized query with better performance
                console.log(`🔐 Looking up user: ${email.substring(0, 3)}***`);
                const loginStartTime = Date.now();

                const [users] = await executeWithRetry(
                    pool,
                    'SELECT id, email, password, name, roles, is_admin FROM users WHERE email = ? AND status = 1 LIMIT 1',
                    [email]
                );

                const queryTime = Date.now() - loginStartTime;
                console.log(`⏱️ Database query completed in ${queryTime}ms`);

                if (users.length === 0) {
                    return {
                        statusCode: 401,
                        headers: corsHeaders,
                        body: JSON.stringify({ success: false, error: 'Invalid credentials' })
                    };
                }

                const user = users[0];
                let isValidPassword = false;

                console.log(`🔒 Validating password for user ${user.id}`);
                const passwordStartTime = Date.now();

                // Optimized password verification - check most likely format first
                if (user.password === password) {
                    // Plain text password (fastest check)
                    isValidPassword = true;
                    console.log('✅ Plain text password match');
                } else if (user.password && (user.password.startsWith('$2') || user.password.startsWith('$2y$') || user.password.startsWith('$2a$') || user.password.startsWith('$2b$'))) {
                    // bcrypt hash (most secure, check second)
                    isValidPassword = await bcrypt.compare(password, user.password);
                    console.log(isValidPassword ? '✅ bcrypt password match' : '❌ bcrypt password mismatch');
                } else {
                    // Legacy hash formats (MD5, SHA256) - last resort
                    const md5Hash = crypto.createHash('md5').update(password).digest('hex');
                    const sha256Hash = crypto.createHash('sha256').update(password).digest('hex');

                    if (user.password === md5Hash) {
                        isValidPassword = true;
                        console.log('✅ MD5 password match (consider upgrading to bcrypt)');
                    } else if (user.password === sha256Hash) {
                        isValidPassword = true;
                        console.log('✅ SHA256 password match (consider upgrading to bcrypt)');
                    } else {
                        console.log('❌ No password format matched');
                    }
                }

                const passwordTime = Date.now() - passwordStartTime;
                console.log(`⏱️ Password validation completed in ${passwordTime}ms`);

                if (!isValidPassword) {
                    return {
                        statusCode: 401,
                        headers: corsHeaders,
                        body: JSON.stringify({ success: false, error: 'Invalid credentials' })
                    };
                }

                const isAdmin = user.is_admin === 1 || user.roles === 'admin' || email === 'info@podops.app';

                console.log(`🎟️ Generating JWT token for user ${user.id}`);
                const tokenStartTime = Date.now();

                const token = jwt.sign(
                    {
                        id: user.id,
                        userId: user.id,
                        email: email,
                        isAdmin: isAdmin,
                        exp: Math.floor(Date.now() / 1000) + (24 * 60 * 60)
                    },
                    process.env.JWT_SECRET || 'podops-secret-key'
                );

                const tokenTime = Date.now() - tokenStartTime;
                const totalTime = Date.now() - totalStartTime;

                console.log(`⏱️ JWT token generated in ${tokenTime}ms`);
                console.log(`🎉 Login successful! Total time: ${totalTime}ms`);

                return {
                    statusCode: 200,
                    headers: corsHeaders,
                    body: JSON.stringify({
                        success: true,
                        token: token,
                        user: {
                            id: user.id,
                            user_id: user.id,
                            email: email,
                            firstName: user.name || 'User',
                            name: user.name || 'User',
                            userType: isAdmin ? 'admin' : 'user',
                            isAdmin: isAdmin,
                            is_admin: isAdmin,
                            hasHosting: true,
                            hasStudio: true
                        },
                        performance: {
                            totalTime: totalTime,
                            queryTime: queryTime,
                            passwordTime: passwordTime,
                            tokenTime: tokenTime
                        }
                    })
                };
            } catch (error) {
                const totalTime = Date.now() - totalStartTime;
                console.error(`❌ Login error after ${totalTime}ms:`, error);

                // Provide more specific error messages for debugging
                let errorMessage = 'Internal server error';
                if (error.code === 'ECONNREFUSED') {
                    errorMessage = 'Database connection refused';
                } else if (error.code === 'ER_ACCESS_DENIED_ERROR') {
                    errorMessage = 'Database access denied';
                } else if (error.code === 'ENOTFOUND') {
                    errorMessage = 'Database host not found';
                } else if (error.message.includes('credentials')) {
                    errorMessage = 'Database credentials unavailable';
                } else if (error.code?.startsWith('ER_')) {
                    errorMessage = 'Database query error';
                }

                return {
                    statusCode: 500,
                    headers: corsHeaders,
                    body: JSON.stringify({
                        success: false,
                        error: errorMessage,
                        requestTime: totalTime,
                        timestamp: new Date().toISOString()
                    })
                };
            }
        }

        // Token verification endpoint
        if (path === '/auth/verify' && method === 'POST') {
            console.log(`🔐 Token verification request started at ${new Date().toISOString()}`);

            try {
                const body = JSON.parse(event.body || '{}');
                let token = body.token;

                // Also check Authorization header
                if (!token && event.headers.Authorization) {
                    token = event.headers.Authorization.replace('Bearer ', '');
                } else if (!token && event.headers.authorization) {
                    token = event.headers.authorization.replace('Bearer ', '');
                }

                if (!token) {
                    return {
                        statusCode: 400,
                        headers: corsHeaders,
                        body: JSON.stringify({ success: false, error: 'Token required' })
                    };
                }

                // Verify and decode the token
                let tokenData;
                try {
                    tokenData = jwt.verify(token, process.env.JWT_SECRET || 'your-secret-key-here');
                    console.log('Token verified for user ID:', tokenData.id);
                } catch (error) {
                    console.error('Token verification failed:', error.message);
                    return {
                        statusCode: 401,
                        headers: corsHeaders,
                        body: JSON.stringify({ success: false, error: 'Invalid token' })
                    };
                }

                // Get user data from database
                const pool = await getDbPool();

                console.log(`🔍 Fetching user data for ID: ${tokenData.id}`);
                const [users] = await executeWithRetry(
                    pool,
                    'SELECT id, email, name, roles, is_admin FROM users WHERE id = ? AND status = 1 LIMIT 1',
                    [tokenData.id]
                );

                if (users.length === 0) {
                    return {
                        statusCode: 401,
                        headers: corsHeaders,
                        body: JSON.stringify({ success: false, error: 'User not found' })
                    };
                }

                const user = users[0];

                // Parse name for firstName extraction
                const nameParts = (user.name || '').split(' ');
                const firstName = nameParts[0] || '';

                // Query actual subscription tables for accurate data
                let hasHosting = false;
                let hasStudio = false;

                console.log(`🔍 Checking subscriptions for user ID: ${user.id}`);

                // Query general subscriptions table
                try {
                    const [subscriptions] = await executeWithRetry(
                        pool,
                        'SELECT type, name, status FROM subscriptions WHERE user_id = ? AND (status = "active" OR status = "1" OR status IS NULL)',
                        [user.id]
                    );

                    console.log('User subscriptions found:', subscriptions.length);
                    subscriptions.forEach(sub => {
                        console.log(`- Type: ${sub.type}, Name: ${sub.name}, Status: ${sub.status}`);
                        if (sub.type && (sub.type.toLowerCase().includes('hosting') || sub.name && sub.name.toLowerCase().includes('hosting'))) {
                            hasHosting = true;
                        }
                        if (sub.type && (sub.type.toLowerCase().includes('studio') || sub.name && sub.name.toLowerCase().includes('studio'))) {
                            hasStudio = true;
                        }
                    });
                } catch (subError) {
                    console.log('Error querying subscriptions table:', subError.message);
                }

                // Query studio-specific subscriptions table
                try {
                    const [studioSubs] = await executeWithRetry(
                        pool,
                        'SELECT * FROM studio_subscriptions WHERE user_id = ? AND (status = "active" OR status = "1" OR status IS NULL)',
                        [user.id]
                    );

                    if (studioSubs.length > 0) {
                        hasStudio = true;
                        console.log('Studio subscriptions found:', studioSubs.length);
                    }
                } catch (studioError) {
                    console.log('Studio subscriptions table not accessible or error:', studioError.message);
                }

                // Fallback to roles if no subscriptions found
                if (!hasHosting && !hasStudio) {
                    console.log('No subscriptions found, checking roles fallback');
                    try {
                        const roles = user.roles ? (typeof user.roles === 'string' ? JSON.parse(user.roles) : user.roles) : [];
                        hasHosting = roles.includes('hosting') || roles.includes('admin');
                        hasStudio = roles.includes('studio') || roles.includes('admin');
                        console.log('Roles-based access:', { hasHosting, hasStudio });
                    } catch (e) {
                        console.log('Roles parsing failed, checking admin status');
                        if (user.is_admin) {
                            hasHosting = true;
                            hasStudio = true;
                        }
                    }
                }

                // Super admin gets everything (always override)
                if (user.id === 26 || user.is_admin) {
                    hasHosting = true;
                    hasStudio = true;
                    console.log('Super admin access granted');
                }

                const responseUser = {
                    id: user.id,
                    email: user.email,
                    firstName: firstName,
                    name: user.name,
                    isAdmin: user.is_admin || user.id === 26,
                    hasHosting: hasHosting,
                    hasStudio: hasStudio
                };

                console.log('User verification successful:', {
                    id: responseUser.id,
                    email: responseUser.email,
                    hasHosting: responseUser.hasHosting,
                    hasStudio: responseUser.hasStudio
                });

                return {
                    statusCode: 200,
                    headers: corsHeaders,
                    body: JSON.stringify({
                        success: true,
                        user: responseUser
                    })
                };

            } catch (error) {
                console.error('Token verification error:', error);
                return {
                    statusCode: 500,
                    headers: corsHeaders,
                    body: JSON.stringify({
                        success: false,
                        error: 'Internal server error',
                        timestamp: new Date().toISOString()
                    })
                };
            }
        }

        return {
            statusCode: 404,
            headers: corsHeaders,
            body: JSON.stringify({ success: false, error: 'Route not found' })
        };

    } catch (error) {
        console.error('Lambda error:', error);
        return {
            statusCode: 500,
            headers: corsHeaders,
            body: JSON.stringify({ success: false, error: 'Internal server error' })
        };
    }
};